from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
import time


driver=webdriver.Chrome()
driver.get('https://www.tripadvisor.de/Restaurant_Review-g187323-d10700265-Reviews-Restaurant_Buschbeck_s-Berlin.html')
#driver.get('https://www.tripadvisor.de/RestaurantSearch-g187323-oa7170-Berlin.html#EATERY_LIST_CONTENTS')

driver.find_element_by_xpath('//div[@data-tracker="All languages"]').click()
time.sleep(2)
driver.implicitly_wait(10)
driver.find_element_by_xpath('//span[@class="taLnk ulBlueLinks"]').click()
time.sleep(2)
driver.implicitly_wait(10)


review_elements = driver.find_elements_by_xpath('//div[@class="review-container"]')
print(len(review_elements))
for review_element in review_elements:
    username = review_element.find_element_by_xpath('./div/div/div/div/div/div[@class="member_info"]/div/div[@class="info_text pointer_cursor"]/div[1]').text
    date = review_element.find_element_by_xpath('./div/div/div/div[2]/div[@class="prw_rup prw_reviews_stay_date_hsx"]').text
    stars = review_element.find_element_by_xpath('./div/div/div/div[2]/span[1]').get_attribute('class')
    title = review_element.find_element_by_xpath('./div/div/div/div[2]/div[1]/a/span').text
    text = review_element.find_element_by_xpath('./div/div/div/div[@class="ui_column is-9"]/div[@class="prw_rup prw_reviews_text_summary_hsx"]/div[@class="entry"]/p').text

    print (username, date, stars, title, text, '\n')




driver.close()
