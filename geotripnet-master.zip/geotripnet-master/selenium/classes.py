class Restaurant(object):
    def __init__(self, name, url, address_street, address_detail, address_district, pricerange, categories, diet, avg_rating, n_reviews, reviews):
        self.name = name
        self.url = url
        self.address_street = address_street
        self.address_detail = address_detail
        self.address_district = address_district
        self.pricerange = pricerange
        self.categories = categories
        self.diet = diet
        self.avg_rating = avg_rating
        self.n_reviews = n_reviews
        self.reviews = reviews

    def __str__(self):
        return (self.name + '\n   ' +
                self.url + '\n   ' +
                self.address_street + '\n   ' +
                self.address_detail + '\n   ' +
                self.address_district + '\n   ' +
                self.pricerange + '\n   ' +
                ','.join(self.categories) + '\n   ' +
                ','.join(self.diet) + '\n   ' +
                self.avg_rating + '\n   ' +
                self.n_reviews + '\n\n\n')
               

class Review(object):
    def __init__(self, restaurant_url, username, date, stars, title, text):
        self.restaurant_url = restaurant_url
        self.username = username
        self.date = date
        self.stars = stars
        self.title = title
        self.text = text

    def __str__(self):
        return (self.username + '\n   ' +
                self.date + '\n   ' +
                self.stars + '\n   ' +
                self.title + '\n   ' +
                self.text + '\n\n')