import time
import re
import csv

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By

from classes import Restaurant, Review

MAX_RETRIES = 10

page_link = 'https://www.tripadvisor.de/Restaurants-g187323-Berlin.html'

options = Options()
options.add_argument('--disable-gpu')
options.add_argument('--headless')
options.add_argument('log-level=3')

driver=webdriver.Chrome(chrome_options=options)

while True:
    restaurant_links = []

    driver.get(page_link)
    for i in range(MAX_RETRIES):
        try:
            time.sleep(1*i) 
            restaurant_elements = driver.find_elements_by_xpath('//div[@class="restaurants-list-ListCell__nameBlock--1hL7F"]/span/a')
            break
        except (NoSuchElementException, StaleElementReferenceException):
            print("No restaurant elements found - something went wrong")
    

    for restaurant_element in restaurant_elements:
        restaurant_links.append(restaurant_element.get_attribute('href'))
    
    for restaurant_link in restaurant_links:
        print('crawling: '+ restaurant_link)
        driver.get(restaurant_link)
        #now get all restaurant meta-data
        print('crawling metadata') 
        for i in range(MAX_RETRIES):
            try:
                time.sleep(1*i) 
                name = driver.find_element_by_xpath('//h1[@class="ui_header h1"]').text
                break
            except (NoSuchElementException, StaleElementReferenceException):
                name = ''

        for i in range(MAX_RETRIES):
            try:
                time.sleep(1*i) 
                address_street = driver.find_element_by_xpath('//*[@id="taplc_resp_rr_top_info_rr_resp_0"]/div/div[4]/div[1]/div/div/div[1]/span[2]/span[@class="street-address"]').text
                break
            except (NoSuchElementException, StaleElementReferenceException):
                address_street = ''

        for i in range(MAX_RETRIES):
            try:
                time.sleep(1*i)
                address_detail = driver.find_element_by_xpath('//*[@id="taplc_resp_rr_top_info_rr_resp_0"]/div/div[4]/div[1]/div/div/div[1]/span[2]/span[@class="extended-address"]').text
                break
            except (NoSuchElementException, StaleElementReferenceException):
                address_detail = ''

        for i in range(MAX_RETRIES):
            try:
                time.sleep(1*i)
                address_district = driver.find_element_by_xpath('//*[@id="taplc_resp_rr_top_info_rr_resp_0"]/div/div[4]/div[1]/div/div/div[1]/span[2]/span[@class="locality"]').text
                break
            except (NoSuchElementException, StaleElementReferenceException):
                address_district = ''

        for i in range(MAX_RETRIES):
            try:
                time.sleep(1*i)
                restaurant_details = driver.find_elements_by_xpath('//div[@class="restaurants-detail-overview-cards-DetailsSectionOverviewCard__tagText--1OH6h"]')
                break
            except (NoSuchElementException, StaleElementReferenceException):
                restaurant_details = ''

        details_text = []
        for detail in restaurant_details:
            details_text.append(detail.text)
        try:
            pricerange = details_text[0]
        except IndexError:
            pricerange = ''
        try:
            categories = details_text[1].split(', ')
        except IndexError:
            categories = ''
        try:
            diet = details_text[2].split(', ')
        except IndexError:
            diet = ''

        for i in range(MAX_RETRIES):
            try:
                time.sleep(1*i)
                avg_rating = driver.find_element_by_xpath('//span[@class="restaurants-detail-overview-cards-RatingsOverviewCard__overallRating--nohTl"]').text
                break
            except (NoSuchElementException, StaleElementReferenceException):
                avg_rating = ''

        for i in range(MAX_RETRIES):
            try:
                time.sleep(1*i)
                n_reviews = re.sub(r'[()]','', driver.find_element_by_xpath('//*[@id="REVIEWS"]/div[1]/div/div[1]/span').text)
                break
            except (NoSuchElementException, StaleElementReferenceException):
                n_reviews = ''       
        
        #write metadata in tables
        print('writing metadata into csv')
        with open(r'.\selenium\restaurants.csv', 'a', newline='', encoding='utf-8') as csv_file:
            writer = csv.writer(csv_file, delimiter='\t')
            writer.writerow([name, restaurant_link, address_street, address_detail, address_district, pricerange, categories, diet, avg_rating, n_reviews])

        #crawl reviews
        for i in range(MAX_RETRIES):
            try:
                time.sleep(1*i)
                driver.find_element_by_xpath('//div[@data-tracker="All languages"]').click()
                break
            except (NoSuchElementException, StaleElementReferenceException):
                print("Did not find All languages Button")
        driver.implicitly_wait(10)

        print('start crawling reviews')
        # reviews = []
        review_page_link = restaurant_link
        while True:
            for i in range(MAX_RETRIES):
                try:
                    time.sleep(1*i)
                    review_elements = driver.find_elements_by_xpath('//div[@class="review-container"]')
                    break
                except (NoSuchElementException, StaleElementReferenceException):
                    print ("No review-container found")


            for review_element in review_elements:
                for i in range(MAX_RETRIES):
                    try:
                        time.sleep(1*i) 
                        username = review_element.find_element_by_xpath('./div/div/div/div/div/div[@class="member_info"]/div/div[@class="info_text pointer_cursor"]/div[1]').text
                        break
                    except (NoSuchElementException, StaleElementReferenceException):
                        username = ''
                
                for i in range(MAX_RETRIES):
                    try:
                        time.sleep(1*i) 
                        date = review_element.find_element_by_xpath('./div/div/div/div[2]/div[@class="prw_rup prw_reviews_stay_date_hsx"]').text
                        date = date[14:]
                        break
                    except (NoSuchElementException, StaleElementReferenceException):
                        date = ''
                
                for i in range(MAX_RETRIES):
                    try:
                        time.sleep(1*i) 
                        stars = review_element.find_element_by_xpath('./div/div/div/div[2]/span[1]').get_attribute('class')
                        stars = stars[-2:]
                        break
                    except (NoSuchElementException, StaleElementReferenceException):
                        stars = ''
                
                for i in range(MAX_RETRIES):
                    try:
                        time.sleep(1*i) 
                        title = review_element.find_element_by_xpath('./div/div/div/div[2]/div[1]/a/span').text
                        break
                    except (NoSuchElementException, StaleElementReferenceException):
                        title = ''

                for i in range(MAX_RETRIES):
                    try:
                        time.sleep(1*i) 
                        text = review_element.find_element_by_xpath('./div/div/div/div[@class="ui_column is-9"]/div[@class="prw_rup prw_reviews_text_summary_hsx"]/div[@class="entry"]/p').text
                        break
                    except (NoSuchElementException, StaleElementReferenceException):
                        text = ''

                # this_review = Review(restaurant_url = restaurant_link, username = username, date = date, stars = stars, title = title, text = text)
                # print(this_review)
                # reviews.append(this_review)
                print('writing review-data into csv')
                with open(r'.\selenium\reviews.csv', 'a', newline='', encoding='utf-8') as csv_file:
                    writer = csv.writer(csv_file, delimiter='\t')
                    writer.writerow([restaurant_link, username, date, stars, title, text])
                with open(r'.\selenium\reviews_lite.csv', 'a', newline='', encoding='utf-8') as csv_file:
                    writer = csv.writer(csv_file, delimiter='\t')
                    writer.writerow([restaurant_link, username, date, stars])
                
            try: 
                next_review_page = driver.find_element_by_xpath('//div[@class="ppr_rup ppr_priv_location_reviews_list_resp"]/div[@class="listContainer hide-more-mobile"]/div[@class="mobile-more"]/div[@class="prw_rup prw_common_responsive_pagination"]/div[@class="unified ui_pagination"]/a[@class="nav next ui_button primary"]')
                review_page_link = next_review_page.get_attribute('href')
                print(review_page_link)
                driver.get(review_page_link) 
            except (NoSuchElementException, StaleElementReferenceException):
                try:
                    next_review_page = driver.find_element_by_xpath('//div[@class="ppr_rup ppr_priv_location_reviews_list_resp"]/div[@class="listContainer hide-more-mobile"]/div[@class="mobile-more"]/div[@class="prw_rup prw_common_responsive_pagination"]/div[@class="unified ui_pagination "]/a[@class="nav next ui_button primary"]')
                    review_page_link = next_review_page.get_attribute('href')
                    print(review_page_link)
                    driver.get(review_page_link)
                except (NoSuchElementException, StaleElementReferenceException):
                    print ('Last review page reached')
                    break

    #finished one page of restaurants
    for i in range(MAX_RETRIES):
        try:
            time.sleep(0.1*i)
            driver.get(page_link)
            next_page = driver.find_element_by_xpath('//div[@class="unified pagination js_pageLinks"]/a[@class="nav next rndBtn ui_button primary taLnk"]')
            page_link = next_page.get_attribute('href')
            driver.get(page_link)
            break
        except (NoSuchElementException, StaleElementReferenceException):
            print ('Last restaurant page reached')
            break

driver.close()
