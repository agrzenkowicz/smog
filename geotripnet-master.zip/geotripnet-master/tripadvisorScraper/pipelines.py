# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import csv
from tripadvisorScraper.items import TripAdvisorItem, ReviewItem

class TripadvisorscraperPipeline(object):
    def process_item(self, item, spider):
        if isinstance(item, TripAdvisorItem):
            return self.handleRestaurant(item, spider)
        elif isinstance(item, ReviewItem):
            return self.handleReview(item, spider)
        else:
            pass

    def handleRestaurant(self, item, spider):
        with open(r'restaurantsScrapy.csv', 'a', newline='', encoding='utf-8') as csv_file:
            writer = csv.writer(csv_file, delimiter='\t')
            writer.writerow([item['name'], item['url'], item['address_street'], item['address_detail'], item['address_district'], item['pricerange'], item['category'], item['avg_rating'], item['n_reviews']])

    def handleReview(self, item, spider):
        with open(r'reviewsScrapy.csv', 'a', newline='', encoding='utf-8') as csv_file:
            writer = csv.writer(csv_file, delimiter='\t')
            writer.writerow([item['url'], item['username'], item['date'], item['stars'], item['title']])


