# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class TripAdvisorItem(scrapy.Item):
	name = scrapy.Field()
	url = scrapy.Field()
	address_street = scrapy.Field()
	address_detail = scrapy.Field()
	address_district = scrapy.Field()
	pricerange = scrapy.Field()
	category = scrapy.Field()
	avg_rating = scrapy.Field()
	n_reviews = scrapy.Field()
	#reviews = scrapy.Field()
 

class ReviewItem(scrapy.Item):
	url = scrapy.Field()
	username = scrapy.Field()
	date = scrapy.Field()
	stars = scrapy.Field()
	title = scrapy.Field()
