import re

import scrapy


from tripadvisorScraper.items import TripAdvisorItem, ReviewItem
from scrapy.selector import Selector
#from scrapy_splash import SplashRequest


class taSpider(scrapy.Spider):
    name = "tripadvisorScraper"
    allowed_urls = ['https://www.tripadvisor.cn']
    start_urls = ['https://www.tripadvisor.cn/Restaurants-g187323-Berlin.html'] #All Restaurants in berlin
    


    def parse (self, response): 
        sel = Selector(response)
        results = sel.xpath('//div[@class="restaurants-list-ListCell__nameBlock--1hL7F"]')
        for result in results:
            taItem = TripAdvisorItem()
            #Name
            taItem['name'] = re.sub(r'[0-9]+.\s','', result.xpath('string(span)').extract_first())

            #URL
            taItem['url'] = "https://www.tripadvisor.cn"+result.xpath('span/a/@href').extract_first()
            url_adjusted_for_lang = taItem['url']+"&filterLang=ALL"
            yield scrapy.Request(url= url_adjusted_for_lang, meta={'taItem': taItem}, callback=self.parse_details)

        #Crawl next page
        nextpage=response.xpath('//div[@class="unified pagination js_pageLinks"]/a[@class="nav next rndBtn ui_button primary taLnk"]/@href').extract()
        print (nextpage)
        print(type(nextpage))
        if nextpage is not None:
            nextlink = "https://www.tripadvisor.cn"+nextpage[0]
            yield scrapy.Request(nextlink, callback=self.parse)

    def parse_details(self, response):
        taItem = response.meta['taItem']
        taItem['address_street'] = response.xpath('//*[@id="taplc_resp_rr_top_info_rr_resp_0"]/div/div[4]/div[1]/div/div/div[1]/span[2]/span[@class="street-address"]//text()').extract_first()
        taItem['address_detail'] = response.xpath('//*[@id="taplc_resp_rr_top_info_rr_resp_0"]/div/div[4]/div[1]/div/div/div[1]/span[2]/span[@class="extended-address"]//text()').extract_first()
        taItem['address_district'] = response.xpath('//*[@id="taplc_resp_rr_top_info_rr_resp_0"]/div/div[4]/div[1]/div/div/div[1]/span[2]/span[@class="locality"]//text()').extract_first()
        taItem['pricerange'] = response.xpath('/html/body/div[2]/div[2]/div[2]/div[2]/div/div[1]/div/div[2]/div/div/div[2]/div[1]/div[@class="restaurants-detail-overview-cards-DetailsSectionOverviewCard__tagText--1OH6h"]//text()').extract_first()
        taItem['category'] = response.xpath('/html/body/div[2]/div[2]/div[2]/div[2]/div/div[1]/div/div[2]/div/div/div[2]/div[2]/div[@class="restaurants-detail-overview-cards-DetailsSectionOverviewCard__tagText--1OH6h"]//text()').extract_first()
        taItem['avg_rating'] = response.xpath('/html/body/div[2]/div[2]/div[2]/div[2]/div/div[1]/div/div[1]/div/div[1]/div[1]/span[@class="restaurants-detail-overview-cards-RatingsOverviewCard__overallRating--nohTl"]//text()').extract_first()
        taItem['n_reviews'] = re.sub(r'[()]','', response.xpath('//*[@id="REVIEWS"]/div[1]/div/div[1]/span//text()').extract_first())

        sel = Selector(response)
        sel_reviews = sel.xpath('//div[@class="review-container"]')

        for sel_review in sel_reviews: 
            revItem = ReviewItem()
            revItem['url']=taItem['url']
            revItem['username'] = sel_review.xpath('./div/div/div/div/div/div[@class="member_info"]/div/div[@class="info_text pointer_cursor"]/div[1]/text()').extract_first()
            revItem['date']  = sel_review.xpath('./div/div/div/div[2]/div[@class="prw_rup prw_reviews_stay_date_hsx"]/text()').extract_first()
            stars = sel_review.xpath('./div/div/div/div[2]/span[1]/@class').extract_first()
            revItem['stars'] = stars #int(stars[-2:])/10
            revItem['title'] = sel_review.xpath('./div/div/div/div[2]/div[1]/a/span//text()').extract_first()
            yield revItem   

        nextpage = response.xpath('//a[@class="nav next ui_button primary"]/@href').extract_first()
        if nextpage is not None and len(nextpage)>0: 
            nextlink = "https://www.tripadvisor.cn"+nextpage+"&filterLang=ALL"
            yield scrapy.Request(nextlink, meta={'taItem': taItem}, callback=self.parse_reviews, dont_filter=True)
        else:
            print("yield item details method")
            yield taItem

        #yield scrapy.Request(url = taItem['url'], meta = {'taItem': taItem}, callback=self.parse_reviews, dont_filter=True, )

    def parse_reviews(self, response): 
        taItem = response.meta['taItem']

        sel = Selector(response)
        sel_reviews = sel.xpath('//div[@class="review-container"]')

        for sel_review in sel_reviews: 
            revItem = ReviewItem()
            revItem['url']=taItem['url']
            revItem['username'] = sel_review.xpath('./div/div/div/div/div/div[@class="member_info"]/div/div[@class="info_text pointer_cursor"]/div[1]/text()').extract_first()
            revItem['date']  = sel_review.xpath('./div/div/div/div[2]/div[@class="prw_rup prw_reviews_stay_date_hsx"]/text()').extract_first()
            stars = sel_review.xpath('./div/div/div/div[2]/span[1]/@class').extract_first()
            revItem['stars'] = stars #int(stars[-2:])/10
            revItem['title'] = sel_review.xpath('./div/div/div/div[2]/div[1]/a/span//text()').extract_first()
            yield revItem

        nextpage = response.xpath('//div[@class="ppr_rup ppr_priv_location_reviews_list_resp"]/div[@class="listContainer hide-more-mobile"]/div[@class="mobile-more"]/div[@class="prw_rup prw_common_responsive_pagination"]/div[@class="unified ui_pagination"]/a[@class="nav next ui_button primary"]/@href').extract_first()
        if nextpage is not None and len(nextpage)>0: 
            nextlink = "https://www."+nextpage+"&filterLang=ALL"
            yield scrapy.Request(nextlink, meta={'taItem': taItem}, callback=self.parse_reviews, dont_filter=True)
        else:
            nextpage = response.xpath('//div[@class="ppr_rup ppr_priv_location_reviews_list_resp"]/div[@class="listContainer hide-more-mobile"]/div[@class="mobile-more"]/div[@class="prw_rup prw_common_responsive_pagination"]/div[@class="unified ui_pagination "]/a[@class="nav next ui_button primary"]/@href').extract_first()
            if nextpage is not None and len(nextpage)>0:
                nextlink = "https://www.tripadvisor.cn"+nextpage+"&filterLang=ALL"
                yield scrapy.Request(nextlink, meta={'taItem': taItem}, callback=self.parse_reviews, dont_filter=True)
            else:
                print("yield item review method")
                yield taItem