# geotripnet


Folder Selenium contains a Selenium scraper which was abandoned because of unsufficient speed.
Folder tripAdvisorScraper contains a Scrapy Spider which was used to obtain all German and Englisch Reviews as well as all Restaurant Data
Geocoder.py uses the geopy package (+ Google Maps Api) to obtain coordinates from adresses. 

Final Data is in geocodedRestaurants.csv and reviewsScrapy.csv


