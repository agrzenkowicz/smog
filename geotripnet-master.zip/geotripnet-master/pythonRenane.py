import os

path = r'C:\Users\wepan\Google Drive\00 Uni\00_Studium\Berlin\Semester 1\Systementwicklung für ein Entwicklungsland\197373-countrys-flags\round'

files = os.listdir(path)

for file in files: 
    fullpath = path+'\\' + file
    renamed = path+'\\'+file[:-4]+"_rnd.png"
    os.rename(fullpath, renamed)
    