from geopy.geocoders import GoogleV3
import csv

locator = GoogleV3 (api_key='API KEY HERE')

with open('restaurantsScrapy1000.csv', encoding='utf-8') as csvfile:
    readCSV = csv.reader(csvfile, delimiter='\t')
    
    counter = 6459

    for row in readCSV:
        address=row[2]+' '+row[4]

        counter +=1

        print(counter,' Geocoding ',row[0])

        location = locator.geocode(address)

        row.append(location.latitude)
        row.append(location.longitude)

        with open(r'geocadedRestaurants.csv', 'a', newline='', encoding='utf-8') as csv_file:
            writer = csv.writer(csv_file, delimiter='\t')
            writer.writerow(row)